export default function Sidebar() {
    return (
      <aside className="w-64 bg-gray-100 p-4">
        <ul>
          <li className="mb-4">Dashboard</li>
          <li className="mb-4">Students</li>
          <li className="mb-4">Chapter</li>
          <li>Settings</li>
        </ul>
      </aside>
    );
  }
  